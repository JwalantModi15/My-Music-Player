package com.techinnovator.jmmusicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;

public class MusicActivity extends AppCompatActivity {

    ImageView imgUp, imgDown, imgPrev, imgPause, imgNext;

    SeekBar volume, seekBar;

    TextView txtStart, txtEnd, musicName;

    String path, title;
    int position;
    ArrayList<String>list;

    MediaPlayer mediaPlayer;

    Runnable runnable;
    Handler handler;
    int totalTime;

    private Animation animation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        setTitle("Play Music");
        imgUp = findViewById(R.id.imgUp);
        imgDown = findViewById(R.id.imgDown);
        imgPrev = findViewById(R.id.imgPrev);
        imgPause = findViewById(R.id.imgPause);
        imgNext = findViewById(R.id.imgNext);
        musicName = findViewById(R.id.musicName);

        volume = findViewById(R.id.volume);
        seekBar = findViewById(R.id.seekBar);

        txtStart = findViewById(R.id.txtStart);
        txtEnd = findViewById(R.id.txtEnd);

        title = getIntent().getStringExtra("title");
        path = getIntent().getStringExtra("path");
        position = getIntent().getIntExtra("position", 0);
        list = getIntent().getStringArrayListExtra("list");

        mediaPlayer = new MediaPlayer();
        musicName.setText(title);

        animation = AnimationUtils.loadAnimation(MusicActivity.this, R.anim.translates_animation);
        musicName.setAnimation(animation);

        try {
            mediaPlayer.setDataSource(path);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
        imgPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer.isPlaying()){
                    mediaPlayer.pause();
                    imgPause.setImageResource(R.drawable.play);
                }
                else{
                    mediaPlayer.start();
                    imgPause.setImageResource(R.drawable.pause);
                }
            }
        });

        imgPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mediaPlayer.reset();

                if(position==0){
                    position = list.size()-1;
                }
                else{
                    position--;
                }
                String filePath = list.get(position);
                try {
                    mediaPlayer.setDataSource(filePath);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    imgPause.setImageResource(R.drawable.pause);
                    String title = filePath.substring(filePath.lastIndexOf("/")+1);
                    musicName.setText(title);
                    musicName.clearAnimation();
                    musicName.startAnimation(animation);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        imgNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.reset();

                if(position==list.size()-1){
                    position = 0;
                }
                else{
                    position++;
                }
                String filePath = list.get(position);
                try {
                    mediaPlayer.setDataSource(filePath);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    imgPause.setImageResource(R.drawable.pause);
                    String title = filePath.substring(filePath.lastIndexOf("/")+1);
                    musicName.setText(title);
                    musicName.clearAnimation();
                    musicName.startAnimation(animation);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser){
                    volume.setProgress(progress);
                    float vol = progress/100f;
                    mediaPlayer.setVolume(vol, vol);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser){
                    mediaPlayer.seekTo(progress);
                    seekBar.setProgress(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                totalTime = mediaPlayer.getDuration();
                seekBar.setMax(totalTime);

                int currentPos = mediaPlayer.getCurrentPosition();
                seekBar.setProgress(currentPos);
                handler.postDelayed(runnable, 1000);

                String duration = createTimeLabel(totalTime);
                String elapsedTime = createTimeLabel(currentPos);

                txtStart.setText(elapsedTime);
                txtEnd.setText(duration);

                if(elapsedTime.equals(duration)){
                    mediaPlayer.reset();
                    if(position==list.size()-1){
                        position = 0;
                    }
                    else{
                        position++;
                    }
                    String filePath = list.get(position);
                    try {
                        mediaPlayer.setDataSource(filePath);
                        mediaPlayer.prepare();
                        mediaPlayer.start();
                        imgPause.setImageResource(R.drawable.pause);
                        String title = filePath.substring(filePath.lastIndexOf("/")+1);
                        musicName.setText(title);
                        musicName.clearAnimation();
                        musicName.startAnimation(animation);

                    }catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        handler.post(runnable);
    }

    public String createTimeLabel(int currentPosition){

        String timeLabel;
        int min, sec;

        min = currentPosition / 1000 / 60;
        sec = currentPosition / 1000 % 60;

        if(sec < 10){
            timeLabel = min+":0"+sec;
        }
        else{
            timeLabel = min+":"+sec;
        }
        return timeLabel;
    }
}