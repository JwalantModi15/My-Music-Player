package com.techinnovator.jmmusicplayer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import com.techinnovator.jmmusicplayer.adapter.MusicAdapter;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    String Media_Path;
    ArrayList<String>list = new ArrayList<>();
    MusicAdapter musicAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("All Songs");
        Media_Path = Environment.getExternalStorageDirectory().getPath()+"/";
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        musicAdapter = new MusicAdapter(list, MainActivity.this);
        recyclerView.setAdapter(musicAdapter);

        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }
        else{
            getAllAudioFiles();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==1 && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
            getAllAudioFiles();
        }
    }

    public void getAllAudioFiles() {
        if(Media_Path!=null){
            File mainFile = new File(Media_Path);
            File[] files = mainFile.listFiles();
            System.out.println(files==null);
            for(File file: files){
                if(file.isDirectory()){
                    scanDirectory(file);
                }
                else{
                    String path = file.getAbsolutePath();
                    if(path.endsWith(".mp3")){
                        list.add(path);
                        musicAdapter.notifyDataSetChanged();
                    }
                }
            }
        }
    }

    public void scanDirectory(File f) {
        if(f!=null){
            File[] files = f.listFiles();

            for(File file: files){
                if(file.isDirectory()){
                    scanDirectory(file);
                }
                else{
                    String path = file.getAbsolutePath();
                    if(path.endsWith(".mp3")){
                        list.add(path);
                        musicAdapter.notifyDataSetChanged();
                    }
                }
            }
        }
    }
}