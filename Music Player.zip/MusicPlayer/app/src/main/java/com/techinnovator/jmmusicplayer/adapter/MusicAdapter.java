package com.techinnovator.jmmusicplayer.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.techinnovator.jmmusicplayer.MainActivity;
import com.techinnovator.jmmusicplayer.MusicActivity;
import com.techinnovator.jmmusicplayer.R;

import java.util.ArrayList;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.MusicHolder>{

    ArrayList<String> list = new ArrayList<>();
    Context context;

    public MusicAdapter(ArrayList<String> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public MusicHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.music_card_view, parent, false);
        return new MusicHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MusicHolder holder, int position) {
        String path = list.get(position);
        String musicTitle = path.substring(path.lastIndexOf("/")+1);
        holder.txtMusic.setText(musicTitle);
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MusicActivity.class);
                intent.putExtra("title", musicTitle);
                intent.putExtra("path", path);
                intent.putExtra("position", position);
                intent.putExtra("list", list);

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MusicHolder extends RecyclerView.ViewHolder{

        TextView txtMusic;
        CardView cardView;
        public MusicHolder(@NonNull View itemView) {
            super(itemView);

            txtMusic = itemView.findViewById(R.id.txtMusic);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }
}
